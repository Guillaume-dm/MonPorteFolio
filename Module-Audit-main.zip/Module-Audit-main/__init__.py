# -*- coding: utf-8 -*-
from . import controllers # Permet l'import du dossier controllers dans le module
from . import models # Permet l'import du dossier models dans le module
