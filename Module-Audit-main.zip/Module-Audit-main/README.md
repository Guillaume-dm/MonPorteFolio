# Module-Audit </br>

Module en Python et XML pour la réalisation d'audits de manière autonome, tout en profitant d'une simplicité de la plate-forme. 
</br>
1- Fonctionalités développées : </br>
○ Création d'un audit via une feuille d'audit vierge. </br>
○ Menu de consultation de ses propres audits et des audits de l'ensemble de l'entreprise. </br>
○ Menu de statistiques. </br>
○ Menu de gestion pour les états d'urgence, ainsi que pour les catégories. </br>

2- Langues disponibles : </br>
○ Français.
