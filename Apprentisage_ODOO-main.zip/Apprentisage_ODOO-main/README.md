# Apprentisage_ODOO </br>

Disponible prochainement : </br>
- Les fichiers de tradcuctions (Arabe, Italien, Français, Polonais) associés à mon module. 
